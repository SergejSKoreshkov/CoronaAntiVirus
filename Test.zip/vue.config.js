module.exports = {
    transpileDependencies: [
        'vuetify'
    ]
}
